package com.example.owlapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.owlapp.R;
import com.example.owlapp.model.Book;

import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.ViewHolder> {

    private Context context;
    private List<Book> books;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Book book);
    }

    public BookAdapter(Context context, List<Book> books) {
        this.context = context;
        this.books = books;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_book, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Book book = books.get(position);

        holder.tvBookTitle.setText(book.getFullTitle());
        holder.tvAuthor.setText(book.getAuthor());
        holder.tvViews.setText(book.getFormattedViews());
        holder.tvChapters.setText(String.valueOf(book.getChapters()));

        // In a real app, you would load the cover image from a URL
        if (book.getId() == 1 && book.getTitle().contains("Haruki Murakami")) {
            // Set specific image for Haruki Murakami book
            holder.imgBook.setImageResource(R.drawable.book_placeholder);
        } else {
            holder.imgBook.setImageResource(R.drawable.book_placeholder);
        }

        // Show download icon
        holder.imgDownloaded.setVisibility(View.VISIBLE);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) {
                    listener.onItemClick(book);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return books.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgBook, imgDownloaded;
        TextView tvBookTitle, tvAuthor, tvViews, tvChapters;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgBook = itemView.findViewById(R.id.imgBook);
            imgDownloaded = itemView.findViewById(R.id.imgDownloaded);
            tvBookTitle = itemView.findViewById(R.id.tvBookTitle);
            tvAuthor = itemView.findViewById(R.id.tvAuthor);
            tvViews = itemView.findViewById(R.id.tvViews);
            tvChapters = itemView.findViewById(R.id.tvChapters);
        }
    }
}
