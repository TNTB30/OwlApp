package com.example.owlapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.owlapp.model.Book;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    private LinearLayout newBooksContainer;
    private LinearLayout popularBooksContainer;
    private LinearLayout recommendedBooksContainer;
    private ImageView navHome, navSearch, navLibrary, navChat, navCart, imgProfile;
    private TextView tvWelcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        // Khởi tạo views
        newBooksContainer = findViewById(R.id.newBooksContainer);
        popularBooksContainer = findViewById(R.id.popularBooksContainer);
        recommendedBooksContainer = findViewById(R.id.recommendedBooksContainer);
        tvWelcome = findViewById(R.id.tvWelcome);
        imgProfile = findViewById(R.id.imgProfile);

        navHome = findViewById(R.id.navHome);
        navSearch = findViewById(R.id.navSearch);
        navLibrary = findViewById(R.id.navLibrary);
        navChat = findViewById(R.id.navChat);
        navCart = findViewById(R.id.navCart);

        // Thiết lập điều hướng
        setupNavigation();

        // Tải dữ liệu sách
        loadBooks();

        // Xử lý sự kiện khi nhấp vào ảnh hồ sơ
        ImageView imgProfle = findViewById(R.id.imgProfile); // hoặc id khác nếu bạn dùng
        imgProfle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, ProfileActivity.class);
                startActivity(intent);
            }
        });
    }

    private void setupNavigation() {
        navHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Đã ở trang chủ
            }
        });

        navSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeActivity.this, SearchActivity.class);
                startActivity(intent);
            }
        });

        navLibrary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Chuyển đến màn hình thư viện (chưa triển khai)
                Intent intent = new Intent(HomeActivity.this, LibraryActivity.class);
                startActivity(intent);
            }
        });

        navChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Chuyển đến màn hình sách đã đọc
                Intent intent = new Intent(HomeActivity.this, ReadBooksActivity.class);
                startActivity(intent);
            }
        });

        navCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Chuyển đến màn hình giỏ hàng (chưa triển khai)
                Toast.makeText(HomeActivity.this, "Tính năng đang phát triển", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void logout() {
        // Xóa thông tin đăng nhập nếu có
        SharedPreferences preferences = getSharedPreferences("user_prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.apply();

        // Quay lại màn hình đăng nhập
        Intent intent = new Intent(HomeActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    private void loadBooks() {
        // Tạo dữ liệu mẫu
        List<Book> newBooks = createSampleBooks("new");
        List<Book> popularBooks = createSampleBooks("popular");
        List<Book> recommendedBooks = createSampleBooks("recommended");

        // Hiển thị sách
        displayBooks(newBooksContainer, newBooks);
        displayBooks(popularBooksContainer, popularBooks);
        displayBooks(recommendedBooksContainer, recommendedBooks);
    }

    private List<Book> createSampleBooks(String type) {
        List<Book> books = new ArrayList<>();

        if ("new".equals(type)) {
            books.add(new Book(1, "Những Kỳ Vọng Lớn Lao", "Great Expectations", "Charles Dickens", "", 1000, 10, "Tiểu thuyết"));
            books.add(new Book(2, "Cha Giàu, Cha Nghèo", "Rich Dad Poor Dad", "Robert T. Kiyosaki", "", 1000, 309, "Kinh doanh - Khởi nghiệp"));
            books.add(new Book(3, "Sức Mạnh Tiềm Thức", "The Power of Your Subconscious Mind", "Dr. Joseph Murphy", "", 2000, 12, "Tâm lý học"));
            books.add(new Book(4, "Người Giàu Có Nhất Thành Babylon", "The Richest Man in Babylon", "George S. Clason", "", 1800, 8, "Tài chính"));
        } else if ("popular".equals(type)) {
            books.add(new Book(5, "Chiến Lược Gia", "The Strategist", "Cynthia Montgomery", "", 3000, 14, "Kinh doanh"));
            books.add(new Book(6, "Bí Mật Triệu Phú", "The Millionaire Next Door", "Thomas J. Stanley", "", 2500, 11, "Tài chính"));
            books.add(new Book(7, "Ikigai", "Ikigai", "Hector Garcia", "", 1700, 9, "Phát triển bản thân"));
            books.add(new Book(8, "Atomic Habits", "Atomic Habits", "James Clear", "", 2200, 13, "Phát triển bản thân"));
        } else {
            books.add(new Book(9, "Tư Duy Tối Ưu", "First Things First", "Stephen R. Covey", "", 1900, 10, "Phát triển bản thân"));
            books.add(new Book(10, "Tiếp Thị 6.0", "Marketing 6.0", "Philip Kotler", "", 2100, 16, "Marketing"));
            books.add(new Book(11, "AI Edge", "The AI Edge", "Karim R. Lakhani", "", 1600, 12, "Công nghệ"));
            books.add(new Book(12, "Lập Trình Cuộc Đời", "Logic", "John Doe", "", 1400, 8, "Công nghệ"));
        }

        return books;
    }

    private void displayBooks(LinearLayout container, List<Book> books) {
        container.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(this);

        for (Book book : books) {
            View bookView = inflater.inflate(R.layout.item_book, container, false);

            ImageView imgBook = bookView.findViewById(R.id.imgBook);
            TextView tvBookTitle = bookView.findViewById(R.id.tvBookTitle);
            TextView tvAuthor = bookView.findViewById(R.id.tvAuthor);

            // Trong ứng dụng thực tế, bạn sẽ tải hình ảnh từ URL
            if (book.getId() == 2) { // Cha Giàu, Cha Nghèo
                imgBook.setImageResource(R.drawable.rich_dad_poor_dad);
            } else {
                imgBook.setImageResource(R.drawable.book_placeholder);
            }

            tvBookTitle.setText(book.getTitle());
            tvAuthor.setText(book.getAuthor());

            // Xử lý sự kiện khi nhấp vào sách
            final int bookId = book.getId();
            bookView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Chuyển đến trang chi tiết sách không hiển thị phần bình luận và đánh giá
                    Intent intent = new Intent(HomeActivity.this, BookDetailActivity.class);
                    intent.putExtra("book_id", bookId);
                    intent.putExtra("show_comments", false); // Không hiển thị phần bình luận và đánh giá
                    startActivity(intent);
                }
            });

            container.addView(bookView);
        }
    }
}
