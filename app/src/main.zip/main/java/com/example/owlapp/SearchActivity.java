package com.example.owlapp;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.owlapp.adapter.SearchResultAdapter;
import com.example.owlapp.model.Book;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SearchActivity extends AppCompatActivity {

    private EditText edtSearch;
    private Button btnCancel;
    private LinearLayout categoryContainer;
    private ListView lvSearchResults;
    private LinearLayout recentSearchLayout;
    private LinearLayout recentSearchContainer;
    private TextView tvNoResults;
    private ImageView navHome, navSearch, navLibrary, navChat, navCart;

    private List<String> categories;
    private List<Book> allBooks;
    private SearchResultAdapter searchResultAdapter;
    private SharedPreferences sharedPreferences;
    private Set<String> recentSearches;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        // Khởi tạo views
        edtSearch = findViewById(R.id.edtSearch);
        btnCancel = findViewById(R.id.btnCancel);
        categoryContainer = findViewById(R.id.categoryContainer);
        lvSearchResults = findViewById(R.id.lvSearchResults);
        recentSearchLayout = findViewById(R.id.recentSearchLayout);
        recentSearchContainer = findViewById(R.id.recentSearchContainer);
        tvNoResults = findViewById(R.id.tvNoResults);

        navHome = findViewById(R.id.navHome);
        navSearch = findViewById(R.id.navSearch);
        navLibrary = findViewById(R.id.navLibrary);
        navChat = findViewById(R.id.navChat);
        navCart = findViewById(R.id.navCart);

        // Khởi tạo dữ liệu
        categories = Arrays.asList("Tiểu thuyết", "Truyện ngắn & Văn học", "Kinh dị & Tâm lý", "Kinh doanh - Khởi nghiệp");
        allBooks = createAllSampleBooks();

        // Khởi tạo adapter
        searchResultAdapter = new SearchResultAdapter(this, new ArrayList<>());
        lvSearchResults.setAdapter(searchResultAdapter);

        // Tải tìm kiếm gần đây
        sharedPreferences = getSharedPreferences("SearchPrefs", MODE_PRIVATE);
        recentSearches = sharedPreferences.getStringSet("recent_searches", new HashSet<>());

        // Thiết lập giao diện
        setupCategories();
        setupSearchBar();
        setupNavigation();
        displayRecentSearches();
    }

    private void setupCategories() {
        LayoutInflater inflater = LayoutInflater.from(this);
        categoryContainer.removeAllViews();

        for (String category : categories) {
            TextView tvCategory = (TextView) inflater.inflate(R.layout.item_category, categoryContainer, false);
            tvCategory.setText(category);

            tvCategory.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    filterBooksByCategory(category);
                }
            });

            categoryContainer.addView(tvCategory);
        }
    }

    private void setupSearchBar() {
        edtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                String query = s.toString().trim();
                if (!query.isEmpty()) {
                    searchBooks(query);
                } else {
                    lvSearchResults.setVisibility(View.GONE);
                    recentSearchLayout.setVisibility(View.VISIBLE);
                    tvNoResults.setVisibility(View.GONE);
                }
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                edtSearch.setText("");
                lvSearchResults.setVisibility(View.GONE);
                recentSearchLayout.setVisibility(View.VISIBLE);
                tvNoResults.setVisibility(View.GONE);
            }
        });

        lvSearchResults.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Book selectedBook = searchResultAdapter.getItem(position);
                // Chuyển đến trang chi tiết sách (chưa triển khai)
                Toast.makeText(SearchActivity.this, "Đã chọn: " + selectedBook.getTitle(), Toast.LENGTH_SHORT).show();

                // Lưu từ khóa tìm kiếm
                saveSearchQuery(edtSearch.getText().toString().trim());
            }
        });
    }

    private void setupNavigation() {
        navHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SearchActivity.this, HomeActivity.class);
                startActivity(intent);
                finish();
            }
        });

        navSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Đã ở trang tìm kiếm
            }
        });

        navLibrary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Chuyển đến màn hình thư viện (chưa triển khai)
                Intent intent = new Intent(SearchActivity.this, LibraryActivity.class);
                startActivity(intent);
            }
        });

        navChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Chuyển đến màn hình sách đã đọc
                Intent intent = new Intent(SearchActivity.this, ReadBooksActivity.class);
                startActivity(intent);
            }
        });

        navCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Chuyển đến màn hình giỏ hàng (chưa triển khai)
                Toast.makeText(SearchActivity.this, "Tính năng đang phát triển", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void searchBooks(String query) {
        List<Book> results = new ArrayList<>();

        for (Book book : allBooks) {
            if (book.getTitle().toLowerCase().contains(query.toLowerCase()) ||
                    (book.getEnglishTitle() != null && book.getEnglishTitle().toLowerCase().contains(query.toLowerCase())) ||
                    book.getAuthor().toLowerCase().contains(query.toLowerCase())) {
                results.add(book);
            }
        }

        if (results.isEmpty()) {
            lvSearchResults.setVisibility(View.GONE);
            recentSearchLayout.setVisibility(View.GONE);
            tvNoResults.setVisibility(View.VISIBLE);
        } else {
            searchResultAdapter.clear();
            searchResultAdapter.addAll(results);
            searchResultAdapter.notifyDataSetChanged();

            lvSearchResults.setVisibility(View.VISIBLE);
            recentSearchLayout.setVisibility(View.GONE);
            tvNoResults.setVisibility(View.GONE);
        }
    }

    private void filterBooksByCategory(String category) {
        List<Book> results = new ArrayList<>();

        for (Book book : allBooks) {
            if (book.getCategory().equals(category)) {
                results.add(book);
            }
        }

        if (results.isEmpty()) {
            lvSearchResults.setVisibility(View.GONE);
            recentSearchLayout.setVisibility(View.GONE);
            tvNoResults.setVisibility(View.VISIBLE);
        } else {
            searchResultAdapter.clear();
            searchResultAdapter.addAll(results);
            searchResultAdapter.notifyDataSetChanged();

            lvSearchResults.setVisibility(View.VISIBLE);
            recentSearchLayout.setVisibility(View.GONE);
            tvNoResults.setVisibility(View.GONE);
        }
    }

    private void saveSearchQuery(String query) {
        if (query.isEmpty()) return;

        Set<String> updatedSearches = new HashSet<>(recentSearches);
        updatedSearches.add(query);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putStringSet("recent_searches", updatedSearches);
        editor.apply();

        recentSearches = updatedSearches;
        displayRecentSearches();
    }

    private void displayRecentSearches() {
        recentSearchContainer.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(this);

        for (String query : recentSearches) {
            View searchItemView = inflater.inflate(R.layout.item_recent_search, recentSearchContainer, false);
            TextView tvSearchQuery = searchItemView.findViewById(R.id.tvSearchQuery);
            tvSearchQuery.setText(query);

            searchItemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    edtSearch.setText(query);
                    searchBooks(query);
                }
            });

            recentSearchContainer.addView(searchItemView);
        }
    }

    private List<Book> createAllSampleBooks() {
        List<Book> books = new ArrayList<>();

        // Tiểu thuyết
        books.add(new Book(1, "Những Kỳ Vọng Lớn Lao", "Great Expectations", "Charles Dickens", "", 1000, 59, "Tiểu thuyết"));
        books.add(new Book(2, "Kiêu Hãnh và Định Kiến", "Pride and Prejudice", "Jane Austen", "", 66000, 61, "Tiểu thuyết"));
        books.add(new Book(3, "Bố Già", "The Godfather", "Mario Puzo", "", 62000, 32, "Tiểu thuyết"));
        books.add(new Book(4, "Cuốn Theo Chiều Gió", "Gone with the Wind", "Margaret Mitchell", "", 1000, 63, "Tiểu thuyết"));
        books.add(new Book(5, "Trăm Năm Cô Đơn", "One Hundred Years of Solitude", "Gabriel García Márquez", "", 1000, 47, "Tiểu thuyết"));

        // Truyện ngắn & Văn học
        books.add(new Book(6, "Dracula", "Dracula", "Bram Stoker", "", 1000, 27, "Truyện ngắn & Văn học"));
        books.add(new Book(7, "Frankenstein", "Frankenstein", "Mary Shelley", "", 66000, 24, "Truyện ngắn & Văn học"));
        books.add(new Book(8, "Sự Im Lặng Của Bầy Cừu", "The Silence of the Lambs", "Thomas Harris", "", 62000, 61, "Truyện ngắn & Văn học"));
        books.add(new Book(9, "Tòa Sáng", "The Shining", "Stephen King", "", 1000, 58, "Truyện ngắn & Văn học"));
        books.add(new Book(10, "Bản Năng Gốc", "Psycho", "Robert Bloch", "", 1000, 17, "Truyện ngắn & Văn học"));

        // Kinh doanh - Khởi nghiệp
        books.add(new Book(11, "Cha Giàu, Cha Nghèo", "Rich Dad Poor Dad", "Robert T. Kiyosaki", "", 1000, 10, "Kinh doanh - Khởi nghiệp"));
        books.add(new Book(12, "Từ Tốt Đến Vĩ Đại", "Good To Great", "Jim Collins", "", 66000, 9, "Kinh doanh - Khởi nghiệp"));
        books.add(new Book(13, "Khởi Nghiệp Tinh Gọn", "The Lean Startup", "Brian Tracy", "", 62000, 13, "Kinh doanh - Khởi nghiệp"));
        books.add(new Book(14, "Dấn Thân", "Lean In", "Sheryl Sandberg", "", 1000, 11, "Kinh doanh - Khởi nghiệp"));
        books.add(new Book(15, "Bắt Đầu với Lý do", "Start with Why", "Simon Sinek", "", 1000, 6, "Kinh doanh - Khởi nghiệp"));

        // Kinh dị & Tâm lý
        books.add(new Book(16, "Cô Bé Lọ Lem", "Cinderella", "Charles Perrault", "", 1000, 5, "Kinh dị & Tâm lý"));
        books.add(new Book(17, "Người Đẹp Ngủ Trong Rừng", "Sleeping Beauty", "Charles Perrault", "", 1000, 7, "Kinh dị & Tâm lý"));

        return books;
    }
}
