package com.example.owlapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.owlapp.model.Book;

import java.util.ArrayList;
import java.util.List;

public class ReadBooksActivity extends AppCompatActivity {

    private LinearLayout booksContainer;
    private ImageView navHome, navSearch, navLibrary, navChat, navCart, imgBack;
    private TextView tvTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_books);

        // Khởi tạo views
        booksContainer = findViewById(R.id.booksContainer);
        navHome = findViewById(R.id.navHome);
        navSearch = findViewById(R.id.navSearch);
        navLibrary = findViewById(R.id.navLibrary);
        navChat = findViewById(R.id.navChat);
        navCart = findViewById(R.id.navCart);
        imgBack = findViewById(R.id.imgBack);
        tvTitle = findViewById(R.id.tvTitle);

        // Thiết lập tiêu đề
        tvTitle.setText("Sách đã đọc");

        // Thiết lập điều hướng
        setupNavigation();

        // Tải danh sách sách đã đọc
        loadReadBooks();

        // Xử lý sự kiện khi nhấp vào nút quay lại
        imgBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void setupNavigation() {
        navHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ReadBooksActivity.this, HomeActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();
            }
        });

        navSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ReadBooksActivity.this, SearchActivity.class);
                startActivity(intent);
            }
        });

        navLibrary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Chuyển đến màn hình thư viện (chưa triển khai)
                Intent intent = new Intent(ReadBooksActivity.this, LibraryActivity.class);
                startActivity(intent);
            }
        });

        navChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Đã ở màn hình sách đã đọc
            }
        });

        navCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Chuyển đến màn hình giỏ hàng (chưa triển khai)
                Toast.makeText(ReadBooksActivity.this, "Tính năng đang phát triển", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadReadBooks() {
        // Tạo danh sách sách đã đọc (giả lập)
        List<Book> readBooks = getReadBooks();

        // Hiển thị danh sách sách
        displayBooks(readBooks);
    }

    private List<Book> getReadBooks() {
        // Trong ứng dụng thực tế, bạn sẽ lấy danh sách từ cơ sở dữ liệu hoặc API
        List<Book> books = new ArrayList<>();

        books.add(new Book(1, "Những Kỳ Vọng Lớn Lao", "Great Expectations", "Charles Dickens", "", 1000, 309, "Tiểu thuyết"));
        books.add(new Book(2, "Cha Giàu, Cha Nghèo", "Rich Dad Poor Dad", "Robert T. Kiyosaki", "", 1000, 309, "Kinh doanh - Khởi nghiệp"));
        books.add(new Book(3, "Bố Già", "The Godfather", "Mario Puzo", "", 62000, 300, "Tiểu thuyết"));
        books.add(new Book(4, "Cuốn Theo Chiều Gió", "Gone with the Wind", "Margaret Mitchell", "", 1000, 20, "Tiểu thuyết"));
        books.add(new Book(5, "Trăm Năm Cô Đơn", "One Hundred Years of Solitude", "Gabriel García Márquez", "", 1000, 20, "Tiểu thuyết"));

        return books;
    }

    private void displayBooks(List<Book> books) {
        booksContainer.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(this);

        for (int i = 0; i < books.size(); i++) {
            Book book = books.get(i);
            View bookView = inflater.inflate(R.layout.item_read_book, booksContainer, false);

            TextView tvNumber = bookView.findViewById(R.id.tvNumber);
            ImageView imgBook = bookView.findViewById(R.id.imgBook);
            TextView tvBookTitle = bookView.findViewById(R.id.tvBookTitle);
            TextView tvAuthor = bookView.findViewById(R.id.tvAuthor);
            TextView tvViews = bookView.findViewById(R.id.tvViews);
            TextView tvComments = bookView.findViewById(R.id.tvComments);
            TextView tvRating = bookView.findViewById(R.id.tvRating);

            // Thiết lập dữ liệu
            tvNumber.setText(String.valueOf(i + 1));

            // Trong ứng dụng thực tế, bạn sẽ tải hình ảnh từ URL
            if (book.getId() == 2) { // Cha Giàu, Cha Nghèo
                imgBook.setImageResource(R.drawable.rich_dad_poor_dad);
            } else {
                imgBook.setImageResource(R.drawable.book_placeholder);
            }

            tvBookTitle.setText(book.getFullTitle());
            tvAuthor.setText(book.getAuthor());
            tvViews.setText(book.getFormattedViews());
            tvComments.setText(String.valueOf(book.getChapters()));

            // Đánh giá giả lập
            float rating = 0;
            switch (book.getId()) {
                case 1: rating = 4.2f; break;
                case 2: rating = 4.0f; break;
                case 3: rating = 4.9f; break;
                case 4: rating = 4.3f; break;
                case 5: rating = 4.5f; break;
                default: rating = 4.0f;
            }

            tvRating.setText(String.format("%.1f", rating));

            // Xử lý sự kiện khi nhấp vào sách
            final int bookId = book.getId();
            bookView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Chuyển đến trang chi tiết sách với chức năng bình luận và đánh giá
                    Intent intent = new Intent(ReadBooksActivity.this, BookDetailActivity.class);
                    intent.putExtra("book_id", bookId);
                    intent.putExtra("show_comments", true); // Hiển thị phần bình luận và đánh giá
                    startActivity(intent);
                }
            });

            booksContainer.addView(bookView);

            // Thêm đường kẻ ngang giữa các mục, trừ mục cuối cùng
            if (i < books.size() - 1) {
                View divider = new View(this);
                divider.setLayoutParams(new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        1
                ));
                divider.setBackgroundColor(getResources().getColor(R.color.teal));
                booksContainer.addView(divider);
            }
        }
    }
}
